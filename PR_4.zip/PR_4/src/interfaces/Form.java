package interfaces;

public interface Form {
    public void changeContactForm();
    public void changeStudentForm();
    public void changeOrderForm();
}